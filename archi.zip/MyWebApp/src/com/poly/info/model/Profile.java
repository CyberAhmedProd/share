package com.poly.info.model;

import java.sql.Date;

public class Profile extends User{
	private int idProfile;
	private String nomUser;
	private String prenomUser;
	private Date birthday;
	public Profile(int idProfile, String nomUser, String prenomUser, Date birthday) {
		super();
		this.idProfile = idProfile;
		this.nomUser = nomUser;
		this.prenomUser = prenomUser;
		this.birthday = birthday;
	}
	public Profile() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Profile(String email,int idProfile, String nomUser, String prenomUser, Date birthday) {
		super(email);
		this.idProfile = idProfile;
		this.nomUser = nomUser;
		this.prenomUser = prenomUser;
		this.birthday = birthday;
	}
	public int getIdProfile() {
		return idProfile;
	}
	public void setIdProfile(int idProfile) {
		this.idProfile = idProfile;
	}
	public String getNomUser() {
		return nomUser;
	}
	public void setNomUser(String nomUser) {
		this.nomUser = nomUser;
	}
	public String getPrenomUser() {
		return prenomUser;
	}
	public void setPrenomUser(String prenomUser) {
		this.prenomUser = prenomUser;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	
}
