package com.poly.info.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.poly.info.service.PersonServiceImpl;

/**
 * Servlet implementation class ServletRemovePerson
 */
@WebServlet("/ServletRemovePerson")
public class ServletRemovePerson extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServletRemovePerson() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doDelete(HttpServletRequest, HttpServletResponse)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		PersonServiceImpl P = new PersonServiceImpl();
		try {
			P.deletePerson(Integer.parseInt(request.getParameter("id")));
			request.setAttribute("state", true);

		} catch (Exception e) {
			// TODO: handle exception

			request.setAttribute("state", false);

		}

		request.setAttribute("list", P.getAllPersons());
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
		rd.forward(request, response);
	}

}
