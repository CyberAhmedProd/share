package com.poly.info.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.poly.info.model.User;
import com.poly.info.service.LoginServiceImpl;

/**
 * Servlet implementation class ServletLogin
 */
@WebServlet("/ServletLogin")
public class ServletLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		LoginServiceImpl L = new LoginServiceImpl();
		User user = new User();
		
		
		// Récupérer les données recues du formulaire 
        user.setEmail(request.getParameter("user"));
        user.setPassword(request.getParameter("pass"));
        
        
        //si l'un des champs est vide
        if ("".equals(user.getEmail()) || "".equals(user.getPassword())) {
            request.setAttribute("erreurLogin","Votre mot de passe ou email non existant");
            //Redirection vers le formulaire form.jsp
            getServletContext().getRequestDispatcher("/form.jsp")
                .forward(request, response);
        }
        else if(L.login(user.getEmail(),user.getPassword())!=0) {
        	request.setAttribute("id_user", user.getId_user());
        	request.setAttribute("login", user.getEmail());
        	request.setAttribute("exist", true);
        	getServletContext().getRequestDispatcher("/index.jsp")
            .forward(request, response);
        }
        //Sinon 
        else {
            
            //request.setAttribute("password", passwordEntred);
            //Redirection vers hello.jsp
        	request.setAttribute("erreurLogin","Votre mot de passe ou email non existant");
            getServletContext().getRequestDispatcher("/form.jsp")
                .forward(request, response);
        }
	}

}
