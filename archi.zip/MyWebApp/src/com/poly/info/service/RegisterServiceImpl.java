package com.poly.info.service;

import java.sql.Connection;
import java.sql.Statement;

import com.poly.info.db.ConnexionDB;
import com.poly.info.model.User;

public class RegisterServiceImpl {
	Connection cn = ConnexionDB.getConnexion();	
	Statement st = null;
	public boolean register(User u) {
		String sql = "INSERT INTO `user`(`email`, `password`) VALUES ('" + u.getEmail()+ "','"+ u.getPassword() + "')";
		
		try {
			st = cn.createStatement();
			st.executeUpdate(sql);
			return true;

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erreur register");

			return false;
		}
	}
}
