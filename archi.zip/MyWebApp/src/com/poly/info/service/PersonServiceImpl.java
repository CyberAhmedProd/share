package com.poly.info.service;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import java.sql.ResultSet;

import com.poly.info.dao.PersonService;
import com.poly.info.db.ConnexionDB;
import com.poly.info.model.Person;

public class PersonServiceImpl implements PersonService{ 

	
	Connection cn = ConnexionDB.getConnexion();
			
			
	Statement st = null;
	
	@Override
	public boolean addPerson(Person p) {
		
		String sql = "INSERT INTO `person`(`Name`, `Age`) VALUES ('" + p.getName() + "',"+ p.getAge() + ")";
		String sql1 ="INSERT INTO `person`(`Name`, `Age`) VALUES ('"+p.getName()+"', "+p.getAge()+")";
		try {
			st = cn.createStatement();
			st.executeUpdate(sql);
			return true;

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erreur add");

			return false;
		}

	}

	@Override
	public boolean deletePerson(int id) {
		String sql = "DELETE FROM `person` WHERE id=" + id;
		try {
			st = cn.createStatement();
			if (st.executeUpdate(sql) == 1) {

				return true;

			}
			// System.out.println("state : "+st.executeUpdate(sql));
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erreur delete");

			return false;
		}

	}

	@Override
	public Person getPersonByName(String name) {
		String sql = "SELECT * FROM `person` WHERE Name ='" + name + "'";
		Person person=null;
		try {
			st =  cn.createStatement();
			ResultSet rs = st.executeQuery(sql);

			while (rs.next()) {
				person = new Person();
				person.setId(rs.getInt("id"));
				person.setName(rs.getString("name"));
				person.setAge(rs.getInt("age"));

			}
			return person;

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erreur affichage");

			return null;
		}

	}

	@Override
	public Person getPerson(int id) {
		String sql = "SELECT `id`, `Name`, `Age` FROM `person` WHERE id =" + id;
		Person person = null;
		try {
			st = cn.createStatement();
			ResultSet rs = st.executeQuery(sql);

			while (rs.next()) {
				person = new Person();
				person.setId(rs.getInt("id"));
				person.setName(rs.getString("Name"));
				person.setAge(rs.getInt("Age"));

			}
			return person;

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());

			return null;
		}

	}

	@Override
	public List<Person> getAllPersons() {
		java.util.List<Person> persons = new ArrayList<Person>();
		String sql = "SELECT * FROM `person`";
		try {
			st = (Statement) cn.createStatement();
			ResultSet rs = (ResultSet) st.executeQuery(sql);
			while (rs.next()) {
				Person person = new Person();
				person.setId(rs.getInt("id"));
				person.setName(rs.getString("Name"));
				person.setAge(rs.getInt("Age"));
				persons.add(person);

			}
			return persons;

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());

			return null;
		}

	}

	@Override
	public boolean updatePerson(Person p) {
		String sql = "UPDATE `person` SET `Name`='" + p.getName() + "',`Age`=" + p.getAge() + " WHERE id=" + p.getId();

		try {
			st = (Statement) cn.createStatement();
			if (st.executeUpdate(sql) == 1) {

				return true;

			}
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erreur add");

			return false;
		}

	}

}
