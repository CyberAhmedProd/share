package com.poly.info.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import com.poly.info.dao.LoginService;
import com.poly.info.db.ConnexionDB;
import com.poly.info.model.User;

public class LoginServiceImpl implements LoginService{
	
	
	Connection cn = ConnexionDB.getConnexion();	
	Statement st = null;
	public int login(String log, String password){
		
		String sql = "SELECT `id_user` FROM `user` WHERE email='" + log + "' AND password='"+ password + "'";
		User user = null;
		try {
			st =  cn.createStatement();
			ResultSet rs = st.executeQuery(sql);

			while (rs.next()) {
				user = new User();
				user.setId_user(rs.getInt("id_user"));

			}
			return user.getId_user();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erreur affichage");

			return 0;
		}
	}

}
