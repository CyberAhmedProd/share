package com.poly.info.dao;

import java.util.List;


import com.poly.info.model.Person;

public interface PersonService {

		
	public boolean addPerson(Person p);

	public boolean deletePerson(int id);
	
	public Person getPerson(int id);

	public boolean updatePerson(Person p);
	
	public List<Person> getAllPersons();

	public Person getPersonByName(String name);
	
}



