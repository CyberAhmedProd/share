package com.poly.info.dao;

public interface ProfileService {

}
