package com.poly.info.dao;

import com.poly.info.model.User;

public interface LoginService {
	
	public int login(String log, String password);
}
