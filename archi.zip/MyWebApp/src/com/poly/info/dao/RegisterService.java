package com.poly.info.dao;

import com.poly.info.model.User;

public interface RegisterService {
	
	public boolean register(User p);
	
}
